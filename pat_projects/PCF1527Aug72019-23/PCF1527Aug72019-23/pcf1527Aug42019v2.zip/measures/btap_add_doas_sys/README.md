

###### (Automatically generated documentation)

# Btapadddoassys

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose which zones to add DOAS to

**Name:** zonesselected,
**Type:** String,
**Units:** ,
**Required:** false,
**Model Dependent:** false




