class BTAPCosting
  def shw_costing(model, prototype_creator)
    puts "test shw"
  end
end