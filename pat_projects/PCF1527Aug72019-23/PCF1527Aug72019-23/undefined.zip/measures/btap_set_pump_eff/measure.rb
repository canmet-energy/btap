# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/
require_relative 'resources/BTAPMeasureHelper'
require 'openstudio-standards'
# start the measure
class BTAPSetpumpEff < OpenStudio::Measure::ModelMeasure

  attr_accessor :use_json_package, :use_string_double
  #Adds helper functions to make life a bit easier and consistent.
  include(BTAPMeasureHelper)
  # human readable name
  def name
    #BEFORE YOU DO anything.. please generate a new <uid>224561f4-8ccc-4f60-8118-34b85359d6f7</uid> and add this to the measure.xml file
    # You can generate a new UUID using the ruby command
    # ruby -e 'require "securerandom";  puts SecureRandom.uuid '
    return "BTAPSetpumpEff"
  end

  # human readable description
  def description
    return "Sets all pump efficiency to specified value "
  end

  # human readable description of modeling approach
  def modeler_description
    return ""
  end

  #Use the constructor to set global variables
  def initialize()
    super()
    #Set to true if you want to package the arguments as json.
    @use_json_package = false
    #Set to true if you want to want to allow strings and doubles in stringdouble types. Set to false to force to use doubles. The latter is used for certain
    # continuous optimization algorithms. You may have to re-examine your input in PAT as this fundamentally changes the measure.
    @use_string_double = true

    # Put in this array of hashes all the input variables that you need in your measure. Your choice of types are Sting, Double,
    # StringDouble, and Choice. Optional fields are valid strings, max_double_value, and min_double_value. This will
    # create all the variables, validate the ranges and types you need,  and make them available in the 'run' method as a hash after
    # you run 'arguments = validate_and_get_arguments_in_hash(model, runner, user_arguments)'
    @measure_interface_detailed = [
        {
            "name" => "eff_cz4",
            "type" => "Double",
            "display_name" => "pump efficiency_cz4",
            "default_value" => 0.82,
            "max_double_value" => 1,
            "min_double_value" => 0.0,
            "is_required" => true
        },
        {
          "name" => "eff_cz5",
          "type" => "Double",
          "display_name" => "pump efficiency_cz5",
          "default_value" => 0.82,
          "max_double_value" => 1,
          "min_double_value" => 0.0,
          "is_required" => true
        },
        {
          "name" => "eff_cz6",
          "type" => "Double",
          "display_name" => "pump efficiency_cz6",
          "default_value" => 0.82,
          "max_double_value" => 1,
          "min_double_value" => 0.0,
          "is_required" => true
        },
        {
          "name" => "eff_cz7A",
          "type" => "Double",
          "display_name" => "pump efficiency_cz7A",
          "default_value" => 0.82,
          "max_double_value" => 1,
          "min_double_value" => 0.0,
          "is_required" => true
        },
        {
          "name" => "effcz7B",
          "type" => "Double",
          "display_name" => "pump efficiency_cz7B",
          "default_value" => 0.82,
          "max_double_value" => 1,
          "min_double_value" => 0.0,
          "is_required" => true
        },
        {
          "name" => "eff_cz8",
          "type" => "Double",
          "display_name" => "pump efficiency_cz8",
          "default_value" => 0.82,
          "max_double_value" => 1,
          "min_double_value" => 0.0,
          "is_required" => true
        }
    ]
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    #Runs parent run method.
    super(model, runner, user_arguments)
    # Gets arguments from interfaced and puts them in a hash with there display name. This also does a check on ranges to
    # ensure that the values inputted are valid based on your @measure_interface array of hashes.
    arguments = validate_and_get_arguments_in_hash(model, runner, user_arguments)
    #puts JSON.pretty_generate(arguments)
    return false if false == arguments
    #You can now access the input argument by the name.
    eff_cz4 = arguments["eff_cz4"]
    eff_cz5 = arguments["eff_cz5"]
    eff_cz6 = arguments["eff_cz6"]
    eff_cz7A = arguments["eff_cz7A"]
    eff_cz7B = arguments["eff_cz7B"]
    eff_cz8 = arguments["eff_cz8"]
    eff_for_this_cz = 0.8
    #determine climate zone
    standard = Standard.build('NECB2017')
    model_hdd = standard.get_necb_hdd18(model)
    if  model_hdd <3000 then
      eff_for_this_cz = arguments["eff_cz4"]
    elsif (model_hdd >= 3000 && model_hdd <4000) then
      eff_for_this_cz = arguments["eff_cz5"]
    elsif  (model_hdd >= 4000 && model_hdd <5000)  then
      eff_for_this_cz = arguments["eff_cz6"]
    elsif  (model_hdd >= 5000 && model_hdd <6000)  then
      eff_for_this_cz = arguments["eff_cz7A"]
    elsif  (model_hdd >= 6000 && model_hdd <7000) then
      eff_for_this_cz = arguments["eff_cz7B"]
    elsif  (model_hdd >= 7000 ) then
      eff_for_this_cz = arguments["eff_cz8"]
    else
      runner.registerError("Couldn't find a climate zone")
    end    
    
    model.getPumpConstantSpeeds.each do |pump|
      if pump.motorEfficiency < 0.82
        pump.setMotorEfficiency(eff_for_this_cz)
      end
    end

    model.getPumpVariableSpeeds.each do |pump|
      if pump.motorEfficiency < 0.82
        pump.setMotorEfficiency(eff_for_this_cz)
      end
    end

    return true
  end
end


# register the measure to be used by the application
BTAPSetpumpEff.new.registerWithApplication
